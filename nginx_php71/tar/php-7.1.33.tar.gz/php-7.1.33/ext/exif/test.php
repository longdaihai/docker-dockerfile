<?php
	include 'test.txt';
?>
